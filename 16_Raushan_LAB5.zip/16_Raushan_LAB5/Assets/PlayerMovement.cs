﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class PlayerMovement : MonoBehaviour
{
    public float speed;
    Rigidbody PlayerRigidbody;
    [SerializeField] int score;
    [SerializeField] int scoretoWin;
    [SerializeField]Text txt;
    private void Start()
    {
        PlayerRigidbody = GetComponent<Rigidbody>();
    }
    void FixedUpdate()
    {
        txt.text = "Score : "+score.ToString();
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        PlayerRigidbody.AddForce(movement * speed * Time.deltaTime);
        if (score >= scoretoWin)
            SceneManager.LoadScene("WinScene");
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == "Coin")
        {
            score += 1;
            Destroy(collision.gameObject);
        }
        if (collision.gameObject.tag == "Danger")
        {
            SceneManager.LoadScene("LoseScene");
        }
    }
}
